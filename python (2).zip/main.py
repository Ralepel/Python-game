import re
import random

counter = 0
woordenlijst = [
    "fietsventieldopje", "przewalskipaard", "pedofiel", "gehandicapt",
    "aquarium", "sousafoon", "wegvervoer", "exclave", "deejay"
]
hetwoord = random.choice(woordenlijst)
lengtewoord = len(hetwoord)
temp = "." * lengtewoord

print(
    "Let's go start playing dikke game GALGJE!!!! Raad beetje letters en kijk of je begaafd bent!"
)
print("Het woord heeft " + str(lengtewoord) + " letters")
