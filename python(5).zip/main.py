import re
import random


counter = 0
woordenlijst = [
    "fietsventieldopje", "przewalskipaard", "pedofiel", "gehandicapt",
    "aquarium", "sousafoon", "wegvervoer", "exclave", "deejay", "herfststrom", "werkschrift"
]
hetwoord = random.choice(woordenlijst)
lengtewoord = len(hetwoord)
temp = "." * lengtewoord

print(
    "Let's go start playing dikke game GALGJE!!!! Raad beetje letters en kijk of je begaafd bent!"
)
print("Het woord heeft " + str(lengtewoord) + " letters")

while True:
    userguess = (input(": "))
    match = re.search(userguess, hetwoord)
    if userguess == hetwoord:  #als je het woord heb geraden
        print('je heb het woord ' + '"' + hetwoord + '"' + " geraden")
        break

    elif match:  #goed geraden letter
        print("Goed geraden!")
        for i in range(0, lengtewoord):
            if userguess == hetwoord[i]:
                temp = temp[:i] + userguess + temp[i + 1:]
        print(temp)

    else:  # fout geraden
        print("Och Och Och, stomme gans. Dommerd!")
        counter = counter + 1
        if counter == 1:
            print(""" 
            __________/|__   
       
             """)
        elif counter == 2:
            print(""" 
          _____________      
                     \|
                      |
                      |
                      |
                      |
           __________/|__   
             """)
        elif counter == 3:
            print(""" 
          _____________      
           |         \|
           0          |
                      |
                      |
                      |
           __________/|__     
            """)
        elif counter == 4:
            print(""" 
          _____________ 
           |         \|
           0          |
          \|/         |
           |          |
                      |
           __________/|__ 

            """)
        elif counter == 5:
            print(""" 
          _____________ 
           |         \|
           0          |
          \|/         |
           |          |
          / \         |
           __________/|__ 
   
                """)

            print(" Das pech leventjes weg.... :(")
            print('het woord was' + '"' + hetwoord + '"')
            break
        else:
            pass
