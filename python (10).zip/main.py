import re
import random
game = True

counter = 0
woordenlijst = [
    "informatica", "informatiekunde", "spelletje", "aardigheidje", "scholier", "israKech", "fotografie", "waardebepaling", "specialiteit", "verzekering", "universiteit", "heesterperk"
]
hetwoord = random.choice(woordenlijst)
lengtewoord = len(hetwoord)
temp = "." * lengtewoord
nieuwwoord = random.choice(woordenlijst)

print(
    "Wat leuk dat u ervoor gekozen heeft ons unieke spel te spelen. Wij voelen ons vereerd. Laten we dan maar snel beginnen! Probeer de juiste letters van het verborgen woord te raden. Eens kijken hoe slim u eigenlijk bent."
)
print("Het verborgen woord heeft wel niet " + str(lengtewoord) + " letters! Succes daarmee!")
print( "Je hebt 5 levens om dit woord te raden.")


while game == True:
    userguess = (input(": "))
    match = re.search(userguess, hetwoord)
    
    if userguess == hetwoord:  
        print('je heb het woord ' + '"' + hetwoord + '"' + " geraden ( ͡° ͜ʖ ͡°)")
      
        
        break
   

    elif match:
        print("Goed geraden!")
        for i in range(0, lengtewoord):
            if userguess == hetwoord[i]:
                temp = temp[:i] + userguess + temp[i + 1:]
        print(temp)
      
    
    else:  
        counter = counter + 1
        Fouteletters= userguess 
        if counter == 1:
            print("Och Och Och, stomme gans.")
            print(""" 
            __________/|__   
       
             """)
            print("Foute letters:", end=' ')
            print(Fouteletters)
            
               
           
            print("Je hebt nog 4 levens over.")
          
            
               
          
        elif counter == 2:
            print("Dommerd!")
            print(""" 
          _____________      
                     \|
                      |
                      |
                      |
                      |
           __________/|__   
             """)
            print('Foute letters:', end=' ')
            
            print( "Je hebt nog 3 levens over." )
          
        elif counter == 3:
            print("Doe eens je best joh....")
            print(""" 
          _____________      
           |         \|
           0          |
                      |
                      |
                      |
           __________/|__     
            """)
            print('Foute letters:', end=' ')
            print(Fouteletters)
            print( "Je hebt nog 2 levens over." )
          
        elif counter == 4:
            print("Het wordt er ook niet beter op hé...")
            print(""" 
          _____________ 
           |         \|
           0          |
          \|/         |
           |          |
                      |
           __________/|__ 

            """)
            print('Foute letters:', end=' ')
            print(Fouteletters)
            print( "Je hebt nog 1 leven over." )
          
        elif counter == 5:
            print("Je hebt 0 levens meer over.")
            print("Das pech leventjes weg.... :(")
            print(""" 
          _____________ 
           |         \|
           0          |
          \|/         |
           |          |
          / \         |
           __________/|__ 
   
                """)
            print('Foute letters:', end=' ')
            print(Fouteletters)
            print('Het woord was ' + '"' + hetwoord + '".')
          
        else:
          break
       
