print(
    "Let's go start playing dikke game GALGJE!!!! Raad beetje letters en kijk of je begaafd bent!"
)